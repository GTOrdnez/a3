import { atom } from "jotai";

export const favouritesAtom = atom([]);
