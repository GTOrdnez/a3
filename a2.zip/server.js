/*********************************************************************************
 * WEB422 – Assignment 2
 *
 * I declare that this assignment is my own work in accordance with Seneca's
 * Academic Integrity Policy:
 *
 * https://www.senecapolytechnic.ca/about/policies/academic-integrity-policy.html
 *
 * Name: Guillermo Torrez Student ID: 145795233 Date: Nov 7th, 2025
 *
 ********************************************************************************/